/**** Fichero encript.h   ***/

extern void generar_pagina_encriptada(pagina in_page, pagina *out_page);


