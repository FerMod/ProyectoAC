/**** Fichero encript_aux.h   ***/

extern void encript (unsigned char *char1, unsigned char *char2);

