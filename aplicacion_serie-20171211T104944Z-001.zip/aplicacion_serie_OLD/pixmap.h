/* Fichero: pixmap.h */

#define NEGRO   0
#define BLANCO  255
#define MAX_VAL 256     /* Rango de posibles valores de grises */

typedef struct
{
  int w;                 /* Width */
  int h;                 /* Height */
  unsigned char *dat;    /* Image */
  unsigned char **im;
}pagina;


extern int load_pixmap(char *filename, pagina *ipage);
extern void store_pixmap(char *filename, pagina opage);

extern void  generar_pagina(pagina *opage, int h, int w, unsigned char val);
extern void  borrar_pagina(pagina ipage);


