/************************************************************************************
     Fichero: upload.c

       Contiene las funciones para preparar la subida de la pagina a la nube
***********************************************************************************/

#include "pixmap.h"
#include "upload_aux.h"


/* Prepara la subida de la pagina a la nube                         */
/***********************************************************************************/

void preparar_subida(pagina in_page)
{
	
int i;
int j;
int h = in_page.h;
int w = in_page.w;

	for(i = 0; i < h; i++){
		for(j = 0; j < w; j++){
			upload(in_page.im[i][j], i, j, h, w);
		}
	}

}
