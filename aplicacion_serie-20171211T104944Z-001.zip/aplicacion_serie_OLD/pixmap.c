/* Fichero: pixmap.c */

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>

#ifdef unix
#include <unistd.h>
#include <sys/stat.h>
#define O_BINARY 0
#define IO_LEN	(1<<30)	
#endif

#if defined(THINK_C) || defined(__MWERKS__)
#include <unix.h>
#define IO_LEN	(1<<14)	
#endif

#ifndef FALSE
#define FALSE 0
#define TRUE  1
#endif

#ifdef sun
extern char *sys_errlist[];
char *strerror(int err)
{
return sys_errlist[err];
}
#endif


typedef struct 
{
  int w;                 /* Width */
  int h;                 /* Height */
  unsigned char *dat;    /* Pagina */
  unsigned char **im;
}pagina;


#define MAGIC_PGM	"P5\n"

static int match_key(int fd, char *key)
{
  char buf[80];

  read(fd, buf, strlen(key));
  if( strncmp(buf, key, strlen(key)) != 0 )
    return FALSE;
  else
    return TRUE;
}

static void skip_comment(int fd, char code, char *c)
{
  while( *c == code )
    {
      while( (read(fd, c, 1) == 1 ) && (*c != '\n') ) ;
      read(fd, c, 1);
    }
}

static void read_header_line(int fd, char *buf)
{
  int i;

  i = 1;
  while( (read(fd, &buf[i], 1) == 1 ) && (buf[i] != '\n') && (buf[i] != '\r') && (i<79) )
    i++;
  buf[i] = 0;
}

static int get_pgm_header(int fd, char *magic, int *width, int *height)
{
  char buf[80];

  if( !match_key(fd, magic) )
    return FALSE;
  read(fd, buf, 1);
  skip_comment(fd, '#', buf);
  read_header_line(fd, buf);
  sscanf(buf, "%d %d", width, height);
  read(fd, buf, 1);
  skip_comment(fd, '#', buf);
  read_header_line(fd, buf);
  return TRUE;
}

static int open_read(char *filename)
{
  int fd;

  if( (fd = open(filename, O_BINARY|O_RDONLY)) < 0 )
    fprintf(stderr, "can't reset file `%s': %s\n", filename, strerror(errno));
  return fd;
}

static int open_read_pixmap(char *filename, char *magic, int *width, int *height)
{
  int fd;

  if( (fd = open_read(filename)) < 0)
    return fd;
  if( !get_pgm_header(fd, magic, width, height) )
    {
      fprintf(stderr, "can't read header of %s\n", filename);
      return -1;
    }
  return fd;
}

static unsigned char *alloc_pixmap(long size)
{
  unsigned char *data;

  if( (data = (unsigned char *)malloc(size)) == NULL )
    {
    fprintf(stderr, "malloc error\n");
    return NULL;
    }
  return data;
}

static void load_data(int fd, unsigned char *data, long size)
{
  char *buffer;
  int count;

  buffer = (char *)data;
  while( size > 0 )
    {
    count = IO_LEN;
    if( count > size )
      count = size;
    read(fd, buffer, count);
    buffer += count;
    size -= count;
    }
}


int load_pixmap(char *filename, pagina *ipage)
{
  int fd,i;
  long size;
  unsigned char *data;

  if( (fd = open_read_pixmap(filename, MAGIC_PGM, &(ipage->w), &(ipage->h))) < 0)
    return FALSE;
  size = (long)ipage->w * ipage->h;
  data = alloc_pixmap(size);
  if( data != NULL )
    load_data(fd, data, size);
  close(fd);
  ipage->dat = data;
  ipage->im = (unsigned char **)malloc(ipage->h * sizeof(unsigned char *));
  for(i=0; i<ipage->h ; i++) ipage->im[i]=&ipage->dat[i*ipage->w];

  return TRUE;
}


static void put_header_line(int fd, char *buf)
{
  write(fd, buf, strlen(buf));
}

static void put_header_info(int fd, char *mark, char *filename)
{
  char buf[80];
  time_t now;

  sprintf(buf, "%sTitulo: %s\n", mark, filename);
  put_header_line(fd, buf);
//  now = time(NULL);
//  sprintf(buf, "%sFecha de creacion: %s", mark, ctime(&now));
//  put_header_line(fd, buf);
}

static void put_pgm_header(int fd, char *magic, int width, int height, char *filename)
{
  char buf[80];

  put_header_line(fd, magic);
  put_header_info(fd, "# ", filename);
  sprintf(buf, "%d %d\n255\n", width, height);
  put_header_line(fd, buf);
}

static int open_write(char *filename)
{
  int fd;

#if defined(THINK_C) || defined(__MWERKS__)
  if( (fd = open(filename, O_BINARY|O_CREAT|O_TRUNC|O_RDWR)) < 0 )
#else
  if( (fd = open(filename, O_BINARY|O_CREAT|O_TRUNC|O_RDWR, S_IREAD|S_IWRITE)) < 0 )
#endif
    fprintf(stderr, "can't rewrite file `%s': %s\n", filename, strerror(errno));
  return fd;
}

static void store_data(int fd, unsigned char *data, long size)
{
  char *buffer;
  int count;
  
  buffer = (char *)data;
  while( size > 0 )
    {
    count = IO_LEN;
    if( count > size )
      count = size;
    write(fd, buffer, count);
    buffer += count;
    size -= count;
    }
}

void store_pixmap(char *filename, pagina opage)
{
  int fd;
  
  if( (fd = open_write(filename)) < 0 )
    return;
  put_pgm_header(fd, MAGIC_PGM, opage.w, opage.h, filename);
  store_data(fd, opage.dat, (long)opage.w*opage.h);
  close(fd);
}

//================================================================================================

void  generar_pagina(pagina *opage, int h, int w, unsigned char val)
{
  int i, j;

  opage->h = h;
  opage->w = w;

  // asignar memoria a la pagina
  if ( (opage->dat = (unsigned char *) malloc(w*h * sizeof(unsigned char))) == NULL )
  {
    fprintf(stderr, "Funcion generar_pagina: malloc error\n");
    exit(1);
  }

  // crear la estructura de punteros a las filas
  if ( (opage->im = (unsigned char **) malloc(h * sizeof(unsigned char *))) == NULL )
  {
    fprintf(stderr, "Funcion generar_pagina: malloc error\n");
    exit(1);
  }
  for(i=0; i<h; i++) opage->im[i] = &opage->dat[i*w];

  // inicializar los pixeles de la pagina
  memset(opage->dat, val, h*w);

  return;
}

void  borrar_pagina(pagina ipage)
{
  free(ipage.dat);
  free(ipage.im);
}




