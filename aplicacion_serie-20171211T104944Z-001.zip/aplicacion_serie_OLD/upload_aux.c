/************************************************************************************
     Fichero: upload_aux.c

       Prepara la subida de un pixel de la pagina. Funciones auxiliares

***********************************************************************************/

#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#define NANOSEC 1
#define N 20


void upload(unsigned char vp, int i, int j, int h, int w)
{
	int k;
	float aux;

	if ((i<h/2)&&((i%32)==0)) 
		for (k=0;k<N;k++) aux=aux+sqrt(vp+i*j+1)+pow(vp,4);
}

/*
void upload(unsigned char vp, int i, int j, int h, int w)
{
        int k;
        float aux;

        struct timespec t0;
        t0.tv_sec=0;
        t0.tv_nsec=NANOSEC;
        if ((i<h/4)&&((i%32)==0)) nanosleep(&t0,NULL); 
}
*/
