/**** Fichero filtro.h   ***/

double filtrar_pagina(pagina *in_page, pagina *out_page);
void copiar_pagina(pagina *in_page, pagina *out_page);
extern void generar_pagina_filtrada(pagina *in_page, pagina *out_page, float limite);



