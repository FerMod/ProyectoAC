/**** Fichero upload.h   ***/

extern void preparar_subida(pagina in_page);


