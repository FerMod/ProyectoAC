/**** Fichero upload_aux.h   ***/

extern void upload (unsigned char vp1, int i, int j, int h, int w);

