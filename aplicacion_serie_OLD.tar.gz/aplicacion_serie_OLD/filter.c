/************************************************************************************
   Fichero: filter.c

   Contiene las funciones para el filtrado de la pagina
***********************************************************************************/
#include <math.h>
#include "pixmap.h"
#include <stdio.h>

#define NUM_IT 100
#define FILTER_SIZE 3

/* Aplicar filtro a una pagina                                  */
/****************************************************************/
double filtrar_pagina(pagina *in_page, pagina *out_page)
{
	double sum, media;
	float filter, min;
	media = 0.0;
	min	= MAX_VAL;
	filter = (double) 1/(FILTER_SIZE*FILTER_SIZE);
    
    int x, y;
    for(x = 1; x <in_page-> h-1; x++) {
		for(y = 1; y <in_page-> w-1; y++) {
		
			sum = (in_page->im[x-1][y-1] + in_page->im[x-1][y] + in_page->im[x-1][y+1] 
					+ in_page->im[x][y-1] + in_page->im[x][y] + in_page->im[x][y+1] 
					+ in_page->im[x+1][y-1] + in_page->im[x+1][y] + in_page->im[x+1][y+1])
					* filter;

			media += sum;
			out_page->im[x][y] = sum;
			
			if(out_page->im[x][y] < min) {
				min = out_page->im[x][y];
			}
		}
		
		
	}
	
	media /= (x*y);
	return media-min;
}

/* Copia la pagina definitiva en la pagina de salida out_page  */
/******************************************************/
void copiar_pagina(pagina *in_page, pagina *out_page)
{
	int i,j;

	for (i=0;i<in_page->h;i++)
		for (j=0;j<in_page->w;j++) out_page->im[i][j]=in_page->im[i][j];
}


/* Genera la pagina filtrada               */
/*******************************************/
void generar_pagina_filtrada(pagina *in_page, pagina *out_page, float limite)
{
	generar_pagina(out_page, in_page->h, in_page->w, NEGRO);
	copiar_pagina(in_page,out_page);
	
	int i=0;
	float media = (double)limite;
	while (i < NUM_IT && media >= limite){
		media = filtrar_pagina(in_page, out_page);
		printf("i: %d\nmedia: %f\n", i, media);
		copiar_pagina(out_page,in_page);
		i++;
	}
}
