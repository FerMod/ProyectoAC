/************************************************************************************
     Fichero: encript.c

 	Generar la pagina encriptada 
	
***********************************************************************************/

#include "pixmap.h"
#include "encript_aux.h"
#include <stdio.h>

void generar_pagina_encriptada(pagina in_page, pagina *out_page)
{
	
	generar_pagina(out_page, in_page.h, in_page.w,NEGRO);
	
	int i, j;
	unsigned char c1, c2;
	// Recorrer la imagen encriptando los pixeles de 2 en 2
	for(i = 0; i < in_page.h - 1; i++) {
        for(j = 0; j < in_page.w - 1; j += 2) {
			
			c1 = in_page.im[i][j];
			c2 = in_page.im[i][j+1];
			
			encript(&c1, &c2);
			
			out_page->im[i][j] = c1;
			out_page->im[i][j+1] = c2;
		}
	}

}			
