/************************************************************************************
     Fichero: encript_aux.c

 	Funcion para encriptar dos pixeles de la pagina

***********************************************************************************/

#include "pixmap.h"
#include <stdio.h>

#define SIZE 2
	
//encriptado de 2 pixeles
void encript (unsigned char *char1, unsigned char *char2)
{
	//Clave para encriptar los pixeles
	int key[SIZE][SIZE] = {
			{21, 35},
			{18, 79},            
	};
	
	unsigned char *pixels[SIZE] = {char1, char2};
	int encryptedPixels[SIZE];
	
	int i, j, temp;	
	for (i = 0; i < SIZE; i++) {
		for (j = 0; j < SIZE; j++) {
			encryptedPixels[i] += (key[i][j] * (int)*pixels[j]);   
		} 
		encryptedPixels[i] %= 256;
	}
	
	int k;
	for (k = 0; k < SIZE; k++) {
		*pixels[k] = encryptedPixels[k];
	}
}



/*
import java.util.Arrays;

public class TestHillCipher {

    public static void main(String[] args) {

        int[][] key = {
                {21, 35},
                {18, 79},            
        };
        
        int[] pixels = {125, 137};
        
        HillCipher hillCipher = new HillCipher();
        int[] encrypted = hillCipher.encrypt(key, pixels);
        
        System.out.println(Arrays.toString(encrypted));
        
    }

}
public class HillCipher {

    public int[] encrypt(int[][] key, int[] pixels) {

        int[] encryptedPixels = new int[2];

        for (int i = 0; i < key.length; i++) {
            for (int j = 0; j < key[i].length; j++) {
                encryptedPixels[i] += key[i][j] * pixels[j];            
            }    
            encryptedPixels[i] %= 256;
        }

        return encryptedPixels;

    }
    
}
*/
